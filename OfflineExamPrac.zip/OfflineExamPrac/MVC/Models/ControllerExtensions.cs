using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.IO;

public static class ControllerExtensions
{
    public static string RenderViewToString<TModel>(this Controller controller, string viewName, TModel model)
    {
        var httpContext = controller.HttpContext;
        httpContext.Response.Body = new MemoryStream();
        var viewResult = new ViewResult { ViewName = viewName, ViewData = new ViewDataDictionary<TModel>(new EmptyModelMetadataProvider(), new ModelStateDictionary()) { Model = model } };

        var viewEngine = controller.HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as ICompositeViewEngine;

        var view = viewEngine.FindView(controller.ControllerContext, viewResult.ViewName, false).View;

        var viewContext = new ViewContext(
            controller.ControllerContext,
            view,
            viewResult.ViewData,
            viewResult.TempData,
            TextWriter.Null,
            new HtmlHelperOptions()
        );

        var t = view.RenderAsync(viewContext);
        t.Wait();

        httpContext.Response.Body.Position = 0;
        var reader = new StreamReader(httpContext.Response.Body);
        var htmlBody = reader.ReadToEnd();
        httpContext.Response.Body.Dispose();

        return htmlBody;
    }
}
