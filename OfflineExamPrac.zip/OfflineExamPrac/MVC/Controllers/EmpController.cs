using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class EmpController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IEmpRepository _empRepository;

        public EmpController(IHttpContextAccessor httpContextAccessor,IEmpRepository empRepository){
            _httpContextAccessor = httpContextAccessor;
            _empRepository = empRepository;
        }
        
        public IActionResult Index(int id)
        {
            string username=HttpContext.Session.GetString("username");

            if(username==null){
                return RedirectToAction("Login","User");
            }
            ViewBag.Username=username;
            List<tblEmp> emps=_empRepository.GetAllEmps(id);
            
            return View(emps);
        }

        public IActionResult Add(){
            
            string username=HttpContext.Session.GetString("username");

            if(username==null){
                return RedirectToAction("Login","User");
            }
            ViewBag.Username=username;

            ViewBag.Department=_empRepository.GetAllDepartments();

            return View();
        }
        [HttpPost]

        public IActionResult Add(tblEmp emp){
             
            string username=HttpContext.Session.GetString("username");

            if(username==null){
                return RedirectToAction("Login","User");
            }
            var uploadsfolder=Path.Combine("D:\\OfflineExamPrac\\MVC\\wwwroot","images");
            if(!Directory.Exists(uploadsfolder)){
                Directory.CreateDirectory(uploadsfolder);
            }
            var uniquefilename=Guid.NewGuid().ToString()+"_"+emp.Profile.FileName;
            var filepath=Path.Combine(uploadsfolder,uniquefilename);
            using(var stream=new FileStream(filepath, FileMode.Create)){
                emp.Profile.CopyTo(stream);
            }
            emp.c_image=uniquefilename;
            _empRepository.AddEmp(emp);
            ViewBag.Username=username;
             ViewBag.Department=_empRepository.GetAllDepartments();
             int userid=HttpContext.Session.GetInt32("userid")??0;

             return RedirectToAction("Index","Emp",new {id=userid});

        }
        [HttpGet]
        public IActionResult Edit(int id){
             string username=HttpContext.Session.GetString("username");

            if(username==null){
                return RedirectToAction("Login","User");
            }
               ViewBag.Department=_empRepository.GetAllDepartments();

            var emp=_empRepository.GetoneEmp(id);

            return View(emp);

        }
         public IActionResult Edit(tblEmp employee)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "User");
            }

            if (employee.Profile != null)
            {
                var uploadsFolder = Path.Combine("D:\\OfflineExamPrac\\MVC\\wwwroot","images");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var uniqueFileName = Guid.NewGuid().ToString() + "_" + employee.Profile.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    employee.Profile.CopyTo(stream);
                }
                employee.c_image = uniqueFileName;
            }
            else
            {
                // If no new image is provided, retain the existing image
                var oldEmployee = _empRepository.GetoneEmp(employee.c_empid);
                employee.c_image = oldEmployee.c_image;
            }

            _empRepository.UpdateEmp(employee);
            int userId = HttpContext.Session.GetInt32("userid") ?? 0;

            ViewBag.Department = _empRepository.GetAllDepartments();
            return RedirectToAction("Index", "Emp", new { id = userId });
        }

        public IActionResult Delete(int id){
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "User");
            }
            _empRepository.DeleteEmp(id);
            int userId = HttpContext.Session.GetInt32("userid") ?? 0;

            return RedirectToAction("Index", "Emp", new { id = userId });

        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}