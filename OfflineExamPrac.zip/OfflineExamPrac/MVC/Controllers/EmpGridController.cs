using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class EmpGridController : Controller
    {

        private readonly IEmpRepository _empRepository;
        private readonly IWebHostEnvironment hostEnvironment;
        public EmpGridController(IEmpRepository empRepository, IWebHostEnvironment hostEnvironment)
        {
            _empRepository = empRepository;
            this.hostEnvironment = hostEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetAll()
        {

            return Json(_empRepository.GetAllEmp());
        }
        public IActionResult GetAllDepartments()
        {
            return Json(_empRepository.GetAllDepartments());
        }
        public IActionResult Create()
        {
            return View();
        }

        static string file = "";
        [HttpPost]
        public IActionResult Create(tblEmp emp)
        {
            emp.c_image = file;
            _empRepository.AddEmp(emp);
            return Json("Index");


        }

        [HttpPost]
        public IActionResult UploadPhoto(tblEmp city)
        {
            if (city.Profile != null)
            {
                string filename = city.Profile.FileName;
                string filepath = Path.Combine(hostEnvironment.WebRootPath, "images", filename);

                using (var stream = new FileStream(filepath, FileMode.Create))
                {

                    city.Profile.CopyTo(stream);
                }

                file = filename;

            }

            return Json("a");
        }
        public IActionResult Edit(int id)
        {
            var model = _empRepository.GetoneEmp(id);
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(tblEmp city)
        {
            if (file != null && file.Length > 0)
            {
                // If a new image is uploaded, set the c_image property to the new file
                city.c_image = file;
            }
            else
            {
                // If no new image is uploaded, retain the existing image
                tblEmp existingEmp = _empRepository.GetoneEmp(city.c_empid); // Assuming there's a method to get employee by ID
                city.c_image = existingEmp.c_image;
            }

            _empRepository.UpdateEmp(city);
            return Json("Index");


        }
        [HttpDelete]
        public IActionResult Delete(int c_empid)
        {
            _empRepository.DeleteEmp(c_empid);
            return RedirectToAction("Index");
        }

         [HttpPost]
    public IActionResult DeleteSelected(int[] selectedProducts)
    {
        

        if(selectedProducts != null && selectedProducts.Length > 0)
        {
            foreach(var productId in selectedProducts)
            {
                _empRepository.DeleteEmp(productId);
            }

            return Ok(new { message = "Products deleted successfully" });
        }
        else
        {
            return BadRequest(new { message = "No products selected for deletion" });
        }
    }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}