using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Implementation;
using Repositories.Interface;
using Repositories.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;

        private readonly IUserRepository _userRepository;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserController(ILogger<UserController> logger,IHttpContextAccessor httpContextAccessor,IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository=userRepository;
            _httpContextAccessor=httpContextAccessor;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register(){
            return View();
        }
        [HttpPost]

        public IActionResult Register(tblUser user){
                _userRepository.Register(user);

                return RedirectToAction("Login","User");
        }

         public IActionResult Login(){
            return View();
         }   
        [HttpPost]
         public IActionResult Login(tblUser user){
            _userRepository.Login(user.c_email,user.c_password);

            var session=_httpContextAccessor.HttpContext.Session;
            
            int userid=session.GetInt32("userid") ?? 0;
            string role=session.GetString("role");

            if(role=="admin"){
                return RedirectToAction("Index","Admin");
            }
            else if(role=="user"){
                 return RedirectToAction("Index","Emp",new {id=userid});
            }
            else
            {
                return RedirectToAction("Index","User",new {id=userid});
            }
         }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}