using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.Interface
{
    public interface IEmpRepository
    {
         public void AddEmp(tblEmp emp);

         public void UpdateEmp(tblEmp emp);

          public List<tblEmp> GetAllEmps(int id);

             public tblEmp GetoneEmp(int id);

               public void DeleteEmp(int id);

               
        public List<tblDept> GetAllDepartments();

         public List<tblEmp> GetAllEmp();

        

    }
}