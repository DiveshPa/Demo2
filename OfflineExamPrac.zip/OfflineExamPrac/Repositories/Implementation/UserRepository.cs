using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class UserRepository:IUserRepository
    {
        private readonly NpgsqlConnection _conn;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserRepository(IHttpContextAccessor httpContextAccessor,IConfiguration config){
            _httpContextAccessor=httpContextAccessor;
            _conn=new NpgsqlConnection(config.GetConnectionString("DefaultConnection"));
        }

        public void Login(string email,string password){

            try{
                _conn.Open();

                using var cmd=new NpgsqlCommand("select *  from t_masterregister where c_email=@email and c_password=@password;",_conn);

                cmd.Parameters.AddWithValue("@email",email);
                cmd.Parameters.AddWithValue("@password",password);

                var dr=cmd.ExecuteReader();

                if(dr.Read()){
                    var session=_httpContextAccessor.HttpContext.Session;

                    session.SetString("role",dr["c_role"].ToString());
                    session.SetInt32("userid",(int)dr["c_regid"]);
                    session.SetString("username",dr["c_uname"].ToString());
                }

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                _conn.Close();
            }
        }
        public void Register(tblUser user){
            try{
                _conn.Open();

                using var cmd=new NpgsqlCommand("insert into t_masterregister(c_email,c_passsword,c_uname,c_role) values (@email,@password,@uname,@role)",_conn);

                cmd.Parameters.AddWithValue("@email",user.c_email);
                  cmd.Parameters.AddWithValue("@password",user.c_password);
                    cmd.Parameters.AddWithValue("@role",user.c_role);
                      cmd.Parameters.AddWithValue("@uname",user.c_uname);

                      cmd.ExecuteNonQuery();
                      _conn.Close();

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                _conn.Close();
            }
        }
    }
}