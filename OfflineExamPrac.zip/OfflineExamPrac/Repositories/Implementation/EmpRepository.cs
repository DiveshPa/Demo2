using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class EmpRepository:IEmpRepository
    {
        private NpgsqlConnection _conn;

        private IHttpContextAccessor _httpContextAccessor;

        private readonly IConfiguration config;

        public EmpRepository(IConfiguration config, IHttpContextAccessor httpContextAccessor){
            _conn=new NpgsqlConnection(config.GetConnectionString("DefaultConnection"));
            _httpContextAccessor=httpContextAccessor;
        }

        public void AddEmp(tblEmp emp){
            try{
                _conn.Open();

                using var cmd=new NpgsqlCommand("insert into t_masteremp(c_empname,c_gender,c_shift,c_image,c_deptid,c_userid,c_dob)values(@empname,@gender,@shift,@image,@deptid,@userid,@dob)",_conn);
                cmd.Parameters.AddWithValue("@empname",emp.c_empname);
                 cmd.Parameters.AddWithValue("@gender",emp.c_gender);
                 cmd.Parameters.AddWithValue("@shift",string.Join(",",emp.c_shift));
                 cmd.Parameters.AddWithValue("@image",emp.c_image);
                 cmd.Parameters.AddWithValue("@deptid",emp.c_deptid);
                 var session=_httpContextAccessor.HttpContext.Session;
                 var userid=session.GetInt32("userid")?? 0;
                 cmd.Parameters.AddWithValue("@userid",userid);
                  cmd.Parameters.AddWithValue("@dob",emp.c_dob);

                  cmd.ExecuteNonQuery();

                  _conn.Close();
                

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                _conn.Close();
            }
        }
        public void UpdateEmp(tblEmp emp){
            try{
                _conn.Open();

                using var cmd=new NpgsqlCommand("Update t_masteremp set c_empname=@name,c_gender=@gender,c_shift=@shift,c_dob=@dob,c_deptid=@deptid,c_image=@image where c_empid=@id",_conn);
                cmd.Parameters.AddWithValue("@id",emp.c_empid);
                cmd.Parameters.AddWithValue("@gender",emp.c_gender);
                cmd.Parameters.AddWithValue("@name",emp.c_empname);
                 cmd.Parameters.AddWithValue("@shift",string.Join(",",emp.c_shift));
                 cmd.Parameters.AddWithValue("@image",emp.c_image);
                 cmd.Parameters.AddWithValue("@deptid",emp.c_deptid);
                cmd.Parameters.AddWithValue("@dob",emp.c_dob);

                int rowsaffected= cmd.ExecuteNonQuery();

                Console.WriteLine(rowsaffected);


            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                _conn.Close();
            }
        }

        public List<tblEmp> GetAllEmps(int id){
            var Emps=new List<tblEmp>();
            try{
                _conn.Open();
                using var cmd=new NpgsqlCommand("select e.c_empid,e.c_empname,e.c_gender,e.c_shift,e.c_dob,e.c_image,d.c_departmentname,e.c_deptid from t_masteremp e inner join t_kendodepartment d ON d.c_departmentid = e.c_deptid where e.c_userid=@id;", _conn);
                cmd.Parameters.AddWithValue("@id", id);
                using var reader=cmd.ExecuteReader();
                while(reader.Read()){
                    var emp=new tblEmp{
                        c_empid=Convert.ToInt32(reader["c_empid"]),
                        c_deptid=Convert.ToInt32(reader["c_deptid"]),
                        c_empname=reader["c_empname"].ToString(),
                        c_gender=reader["c_gender"].ToString(),
                        c_shift=reader["c_shift"].ToString().Split(',').ToList(),
                        c_dob=Convert.ToDateTime(reader["c_dob"]),
                        c_image=reader["c_image"].ToString(),
                        deptname=reader["c_departmentname"].ToString(),
                    };
                    Emps.Add(emp);
                }
                

            }catch(Exception e){
                Console.WriteLine(e.Message);

            }finally{
                _conn.Close();
            }
            return Emps;    
        }

         public List<tblEmp> GetAllEmp(){
            var Emps=new List<tblEmp>();
            try{
                _conn.Open();
                using var cmd=new NpgsqlCommand("select e.c_empid,e.c_empname,e.c_gender,e.c_shift,e.c_dob,e.c_image,d.c_departmentname,e.c_deptid from t_masteremp e inner join t_kendodepartment d ON d.c_departmentid = e.c_deptid", _conn);
               
                using var reader=cmd.ExecuteReader();
                while(reader.Read()){
                    var emp=new tblEmp{
                        c_empid=Convert.ToInt32(reader["c_empid"]),
                        c_deptid=Convert.ToInt32(reader["c_deptid"]),
                        c_empname=reader["c_empname"].ToString(),
                        c_gender=reader["c_gender"].ToString(),
                        c_shift=reader["c_shift"].ToString().Split(',').ToList(),
                        c_dob=Convert.ToDateTime(reader["c_dob"]),
                        c_image=reader["c_image"].ToString(),
                        deptname=reader["c_departmentname"].ToString(),
                    };
                    Emps.Add(emp);
                }
                

            }catch(Exception e){
                Console.WriteLine(e.Message);

            }finally{
                _conn.Close();
            }
            return Emps;    
        }

         public tblEmp GetoneEmp(int id){
            var Emp=new tblEmp();
            try{
                _conn.Open();
                using var cmd=new NpgsqlCommand("select c_empid,c_empname,c_gender,c_shift,c_image,c_deptid,c_dob from t_masteremp where c_empid=@id ", _conn);
                cmd.Parameters.AddWithValue("@id", id);
                using var reader=cmd.ExecuteReader();
                if(reader.Read()){
                   
                        Emp.c_empid=Convert.ToInt32(reader["c_empid"]);
                        Emp.c_deptid=Convert.ToInt32(reader["c_deptid"]);
                        Emp.c_empname=reader["c_empname"].ToString();
                        Emp.c_gender=reader["c_gender"].ToString();
                        Emp.c_shift=reader["c_shift"].ToString().Split(',').ToList();
                        Emp.c_dob=Convert.ToDateTime(reader["c_dob"]);
                        Emp.c_image=reader["c_image"].ToString();
                }
                

            }catch(Exception e){
                Console.WriteLine(e.Message);

            }finally{
                _conn.Close();
            }
           return Emp;    
        }

        public void DeleteEmp(int id){
            try{
                _conn.Open();

                using var cmd=new NpgsqlCommand("Delete from t_masteremp where c_empid=@id",_conn);
                cmd.Parameters.AddWithValue("@id",id);
                cmd.ExecuteNonQuery();

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                _conn.Close();
            }
        }

        public List<tblDept> GetAllDepartments(){
            var Depts = new List<tblDept>();

            try{
                _conn.Open();

                using var cmd=new NpgsqlCommand("select c_departmentid ,c_departmentname from t_kendodepartment", _conn);

                using var reader=cmd.ExecuteReader();
                while(reader.Read()){
                    var dept=new tblDept{
                        c_departmentid=Convert.ToInt32(reader["c_departmentid"]),
                        c_departmentname=reader["c_departmentname"].ToString(),
                    };
                    Depts.Add(dept);
                }

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                _conn.Close();
            }
            return Depts;
        }




    }
}