using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class tblDept
    {
        public int c_departmentid{ get; set; }

        public string? c_departmentname{ get; set;}

        
    }
}