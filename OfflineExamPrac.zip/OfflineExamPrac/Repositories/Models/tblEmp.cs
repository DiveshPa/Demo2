using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Repositories.Models
{
    public class tblEmp
    {
        public int c_empid{ get; set; }

        public int c_userid{ get; set; }

        public int c_deptid{ get; set; }

        public string c_empname{ get; set;}

        public string c_gender{get; set;}

        public DateTime c_dob{get; set; }

        public IFormFile Profile{ get; set; }

        public string c_image{ get; set; }

        public List<string> c_shift{ get; set; }

        public string deptname { get; set; }
    }
}